# Gridworld parameters
G_UP = 0
G_RIGHT = 1
G_DOWN = 2
G_LEFT = 3




